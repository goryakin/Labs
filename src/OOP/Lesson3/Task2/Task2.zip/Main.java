package OOP.Lesson3.Task2;

public class Main {
    public static void main(String[] args) {
    Galeon ship = new Galeon();
    ship.shoot();
    }
}
