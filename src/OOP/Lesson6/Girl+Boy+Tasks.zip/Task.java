public class Task {
    private String text;
    private boolean isDone;
    private Date date;
    private int priority;

    Task(String text, int priority) {
        this.text = text;
        this.priority = priority;
        isDone = false;
    }

    public int getPriority() {
        return priority;
    }

    public void setDone() {
        isDone = true;
    }

    public boolean isDone() {
        return isDone;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
