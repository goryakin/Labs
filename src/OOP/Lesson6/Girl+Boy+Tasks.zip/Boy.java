public class Boy extends Human {
    private boolean complimentSaid;

    public Boy(String name) {
        super(name, Sex.MALE);
    }

    public void sayCompliment(String text) {
        if(!complimentSaid ) {
            complimentSaid = true;
            removeLast();
        }

    }


}
