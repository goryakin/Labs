public class Girl extends Human {

    public Girl(String name) {
        super(name, Sex.FEMALE);
    }

    public void giveTask(Task task, Date date, Boy boy) {
        if(date.getDay() == 8 && date.getMonth() == 3) {
            boy.addTask(task);
        } else {
            addTask(task);
        }
    }

}
