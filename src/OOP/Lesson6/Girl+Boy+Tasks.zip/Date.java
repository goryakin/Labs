import java.beans.PropertyChangeSupport;

public class Date {
    private int year;
    private int month;
    private int day;
    PropertyChangeSupport pcs = new PropertyChangeSupport(this);

    public Date(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public void nextDay() {
        pcs.firePropertyChange("Новий день", day, day + 1);
        day++;
    }

    public int getDay() {
        return day;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    @Override
    public String toString() {
        return day + "-" + month + "-" + year;
    }
}
