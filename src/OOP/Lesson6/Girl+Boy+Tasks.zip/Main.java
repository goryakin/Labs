public class Main {
    public static void main(String[] args) {
        Girl girl = new Girl("Маша");
        Boy boy = new Boy("Рома");

        Date date = new Date(2019, 3, 8);
        Task task1 = new Task("Забити гвіздок", 2);
        Task task2 = new Task("Задача 2", 7);
        Task task3 = new Task("Задача 3", 4);
        Task task4 = new Task("Задача 4", 4);

        boy.addTask(task1);
        boy.addTask(task2);

        girl.giveTask(task3, date, boy);

        girl.addTask(task4);

        boy.printStatus();
        girl.printStatus();

        boy.sayCompliment("У тебе гарні очі");
        boy.sayCompliment("У тебе гарні очі");
        boy.printStatus();

        date.pcs.addPropertyChangeListener(boy);
        date.pcs.addPropertyChangeListener(girl);
        date.nextDay();

        boy.printStatus();
        girl.printStatus();
    }
}
