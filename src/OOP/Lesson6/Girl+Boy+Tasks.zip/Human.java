import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.PriorityQueue;

public abstract class Human implements PropertyChangeListener {
    private String name;
    private Sex sex;
    private PriorityQueue<Task> tasks;

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        System.out.println("Новий день.");
        tasks.clear();
    }

    enum Sex {
        MALE, FEMALE, NA
    }

    public Human(String name, Sex sex) {
        this.name = name;
        this.sex = sex;
        tasks = new PriorityQueue<>(new TasksByPriorityComparator());
    }

    public String getName() {
        return name;
    }

    public Sex getSex() {
        return sex;
    }

    public void setSex(Sex sex) {
        this.sex = sex;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addTask(Task task) {
        tasks.add(task);
    }
    public int tasksAmount() {
        return  tasks.size();
    }
    public void makeTask() {
        if(!tasks.peek().isDone()) {
            tasks.peek().setDone();
        } else {
            System.out.println("Всі задачі виконані");
        }
    }
    public void removeLast() {
        Object[] tasks1 = tasks.toArray();
        if(tasks.size() > 1 && !((Task)tasks1[1]).isDone()) {
            tasks.remove(tasks1[1]);
        }
    }

    public void printStatus() {
        int done = 0;
        int notDone = 0;
        for(Task task: tasks) {
            if(task.isDone()) {
                done++;
            } else {
                notDone++;
            }
        }
        System.out.println("Виконо задач: " + done);
        System.out.println("Не виконо задач: " + notDone);
    }
}
